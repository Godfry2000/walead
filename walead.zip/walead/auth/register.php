<?php
require '../config/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST["nom"];
    $prenom = $_POST["prenom"];
    $email = $_POST["email"];
    $whatsapp = $_POST["whatsapp"];
    $pays = $_POST["pays"];
    $pseudo = $_POST["pseudo"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT); // Sécurisation du mot de passe

    // Vérifier si l'email existe déjà
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        echo "❌ Cet email est déjà utilisé.";
        exit();
    }

    // Insérer l'utilisateur dans la base de données
    $stmt = $pdo->prepare("INSERT INTO users (nom, prenom, email, whatsapp, pays, pseudo, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
    if ($stmt->execute([$nom, $prenom, $email, $whatsapp, $pays, $pseudo, $password])) {
        echo "✅ Inscription réussie ! <a href='login.php'>Connectez-vous</a>";
    } else {
        echo "❌ Erreur lors de l'inscription.";
    }
}
?>
