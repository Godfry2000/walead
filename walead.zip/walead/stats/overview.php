<div class="stats-container">
    <h2>Analytiques des Performances</h2>
    
    <div class="chart-grid">
        <div class="chart-card">
            <canvas id="contacts-chart"></canvas>
        </div>
        
        <div class="chart-card">
            <canvas id="conversion-chart"></canvas>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Contacts Chart
        new Chart(document.getElementById('contacts-chart'), {
            type: 'line',
            data: {
                labels: <?= json_encode($chart_labels) ?>,
                datasets: [{
                    label: 'Nouveaux contacts/mois',
                    data: <?= json_encode($contact_data) ?>,
                    borderColor: '#25D366',
                    tension: 0.1
                }]
            }
        });

        // Conversion Chart
        new Chart(document.getElementById('conversion-chart'), {
            type: 'doughnut',
            data: {
                labels: ['Convertis', 'En attente'],
                datasets: [{
                    data: [65, 35],
                    backgroundColor: ['#25D366', '#128C7E']
                }]
            }
        });
    </script>
</div>