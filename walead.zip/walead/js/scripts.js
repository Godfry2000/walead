// === Configuration Générale ===
const config = {
    carouselScrollOffset: 320, // Largeur carte + margin
    animationOffset: 100       // Délai avant animation
};

// === Éléments du DOM ===
const domElements = {
    services: {
        track: document.querySelector('.services-track'),
        prevBtn: document.querySelector('.services-carousel .prev'),
        nextBtn: document.querySelector('.services-carousel .next'),
        cards: document.querySelectorAll('.service-card')
    },
    chatBubble: document.querySelector('.chat-bubble'),
    pricingCards: document.querySelectorAll('.price-card')
};

// === Gestion du Carrousel ===
class CarouselManager {
    constructor() {
        this.currentScroll = 0;
        this.maxScroll = domElements.services.track.scrollWidth - domElements.services.track.clientWidth;
        
        this.initEventListeners();
        this.updateButtonStates();
    }

    initEventListeners() {
        // Boutons directionnels
        domElements.services.prevBtn.addEventListener('click', () => this.scroll('prev'));
        domElements.services.nextBtn.addEventListener('click', () => this.scroll('next'));

        // Gestion tactile
        let touchStartX = 0;
        domElements.services.track.addEventListener('touchstart', e => {
            touchStartX = e.touches[0].clientX;
        });

        domElements.services.track.addEventListener('touchend', e => {
            const touchEndX = e.changedTouches[0].clientX;
            this.handleSwipe(touchStartX, touchEndX);
        });
    }

    scroll(direction) {
        const offset = direction === 'next' 
            ? config.carouselScrollOffset 
            : -config.carouselScrollOffset;

        this.currentScroll = Math.max(0, Math.min(
            this.currentScroll + offset,
            this.maxScroll
        ));

        domElements.services.track.scrollTo({
            left: this.currentScroll,
            behavior: 'smooth'
        });

        this.updateButtonStates();
    }

    handleSwipe(startX, endX) {
        const delta = startX - endX;
        if (Math.abs(delta) > 50) {
            this.scroll(delta > 0 ? 'next' : 'prev');
        }
    }

    updateButtonStates() {
        domElements.services.prevBtn.disabled = this.currentScroll <= 0;
        domElements.services.nextBtn.disabled = this.currentScroll >= this.maxScroll - 10;
    }
}

// === Animations au Défilement ===
function initScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, { threshold: 0.1 });

    [...domElements.services.cards, ...domElements.pricingCards].forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        observer.observe(el);
    });
}

// === Gestion du Chat ===
function initChat() {
    domElements.chatBubble.addEventListener('click', () => {
        window.open('https://wa.me/22960001151', '_blank');
    });
}

// === Initialisation au Chargement ===
document.addEventListener('DOMContentLoaded', () => {
    new CarouselManager();
    initScrollAnimations();
    initChat();
});

// === Gestion du Redimensionnement ===
window.addEventListener('resize', () => {
    new CarouselManager().updateButtonStates();
});