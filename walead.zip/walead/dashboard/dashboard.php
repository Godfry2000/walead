<?php
require '../config/session.php';
require '../config/config.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord</title>
</head>
<body>
    <h1>Bienvenue sur votre Tableau de Bord, <?php echo htmlspecialchars($_SESSION["pseudo"]); ?> !</h1>
    <nav>
        <a href="profile.php">Mon Profil</a>
        <a href="../auth/logout.php">Se Déconnecter</a>
    </nav>
</body>
</html>

