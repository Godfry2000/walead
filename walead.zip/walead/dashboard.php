<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require_once "config/config.php";

$query = $pdo->prepare("SELECT nom, prenom, email, numero_whatsapp, pseudo FROM users WHERE id = ?");
$query->execute([$_SESSION['user_id']]);
$user = $query->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - New Lead</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<!-- Menu latéral -->
<div class="d-flex" id="wrapper">
    <div class="bg-dark text-white" id="sidebar">
        <h2 class="text-center py-3">New Lead</h2>
        <ul class="list-unstyled px-3">
            <li><a href="dashboard.php" class="text-white">🏠 Accueil</a></li>
            <li><a href="contacts.php" class="text-white">📋 Mes contacts</a></li>
            <li><a href="chat.php" class="text-white">💬 Messages</a></li>
            <li><a href="chat.php" class="text-white">💬 Messages <span id="notif" class="badge bg-danger">0</span></a></li>
            <li><a href="logout.php" class="text-danger">🚪 Déconnexion</a></li>
        </ul>
    </div>

    <!-- Contenu principal -->
    <div class="container my-4">
        <h2 class="mb-4">Bienvenue sur votre Dashboard, <?= htmlspecialchars($user['pseudo']) ?> !</h2>

        <div class="row">
            <!-- Carte d'informations utilisateur -->
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h4 class="card-title">👤 Informations du profil</h4>
                        <p><strong>Nom :</strong> <?= htmlspecialchars($user['nom']) ?></p>
                        <p><strong>Prénom :</strong> <?= htmlspecialchars($user['prenom']) ?></p>
                        <p><strong>Email :</strong> <?= htmlspecialchars($user['email']) ?></p>
                        <p><strong>Numéro WhatsApp :</strong> <?= htmlspecialchars($user['numero_whatsapp'] ?? 'Non renseigné') ?></p>
                        <p><strong>Pseudo :</strong> <?= htmlspecialchars($user['pseudo']) ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    #wrapper {
        display: flex;
    }
    #sidebar {
        width: 250px;
        height: 100vh;
        position: fixed;
        padding-top: 20px;
    }
    .container {
        margin-left: 260px;
    }
</style>
<script>
function checkNewMessages() {
    $.get("check_notifications.php", function(data) {
        $("#notif").text(data);
    });
}

setInterval(checkNewMessages, 5000);
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
