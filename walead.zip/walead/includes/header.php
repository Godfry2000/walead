<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - WaLead</title>
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <header class="dashboard-header">
        <div class="logo-container">
            <img src="../assets/logo.png" alt="WaLead Logo">
        </div>
        
        <div class="user-menu">
            <div class="user-profile">
                <span><?= htmlspecialchars($_SESSION['user_pseudo']) ?></span>
                <i class="fas fa-chevron-down"></i>
            </div>
            <ul class="dropdown-menu">
                <li><a href="profile.php"><i class="fas fa-user"></i> Profil</a></li>
                <li><a href="settings/security.php"><i class="fas fa-lock"></i> Sécurité</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a></li>
            </ul>
        </div>
    </header>