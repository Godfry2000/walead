<nav class="sidebar">
    <ul class="nav-links">
        <li class="<?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : '' ?>">
            <a href="dashboard.php"><i class="fas fa-home"></i> Tableau de bord</a>
        </li>
        <li class="<?= basename($_SERVER['PHP_SELF']) === 'contacts.php' ? 'active' : '' ?>">
            <a href="contacts/list.php"><i class="fas fa-address-book"></i> Contacts</a>
        </li>
        <li class="<?= basename($_SERVER['PHP_SELF']) === 'stats.php' ? 'active' : '' ?>">
            <a href="stats/overview.php"><i class="fas fa-chart-line"></i> Statistiques</a>
        </li>
        <li class="<?= basename($_SERVER['PHP_SELF']) === 'settings.php' ? 'active' : '' ?>">
            <a href="settings/account.php"><i class="fas fa-cog"></i> Paramètres</a>
        </li>
    </ul>
</nav>