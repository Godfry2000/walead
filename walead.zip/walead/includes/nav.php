<?php
session_start();
?>

<nav>
    <ul>
        <li><a href="index.php">Accueil</a></li>
        <li><a href="services.php">Services</a></li>
        <li><a href="offres.php">Offres</a></li>
        <li><a href="partenaires.php">Partenaires</a></li>
        <li><a href="contact.php">Contact</a></li>
        <?php if (isset($_SESSION['user'])): ?>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="logout.php">Déconnexion</a></li>
        <?php else: ?>
            <li><a href="inscription.php" class="cta-button">Inscription</a></li>
            <li><a href="connexion.php">Connexion</a></li>
        <?php endif; ?>
    </ul>s
</nav>

</nav>