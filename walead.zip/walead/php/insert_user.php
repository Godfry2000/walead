<?php
require '../config/config.php';

$nom = "John";
$prenom = "Doe";
$email = "test@example.com";
$whatsapp = "+22960001151";
$pays = "Bénin";
$pseudo = "johndoe";
$password = password_hash("123456", PASSWORD_DEFAULT); // Hachage du mot de passe

$stmt = $pdo->prepare("INSERT INTO users (nom, prenom, email, whatsapp, pays, pseudo, password) 
                       VALUES (?, ?, ?, ?, ?, ?, ?)");
if ($stmt->execute([$nom, $prenom, $email, $whatsapp, $pays, $pseudo, $password])) {
    echo "✅ Utilisateur inséré avec succès.";
} else {
    echo "❌ Erreur lors de l'insertion.";
}
?>
