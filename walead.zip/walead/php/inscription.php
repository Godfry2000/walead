<?php
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'nom' => htmlspecialchars($_POST['nom']),
        'prenom' => htmlspecialchars($_POST['prenom']),
        'email' => filter_var($_POST['email'], FILTER_SANITIZE_EMAIL),
        'whatsapp' => preg_replace('/[^0-9]/', '', $_POST['whatsapp']),
        'pays' => htmlspecialchars($_POST['pays']),
        'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
        'pseudo' => htmlspecialchars($_POST['pseudo'])
    ];

    try {
        $stmt = $conn->prepare("INSERT INTO users (nom, prenom, email, whatsapp, pays, password, pseudo) 
                               VALUES (?, ?, ?, ?, ?, ?, ?)");
                               
        $stmt->bind_param("sssssss", 
            $data['nom'],
            $data['prenom'],
            $data['email'],
            $data['whatsapp'],
            $data['pays'],
            $data['password'],
            $data['pseudo']
        );

        if($stmt->execute()) {
            $_SESSION['user'] = $data['pseudo'];
            header('Location: dashboard.php');
            exit();
        }
    } catch(mysqli_sql_exception $e) {
        die("Erreur d'inscription : " . $e->getMessage());
    }
}

include '../header.php'; 
?>
<!-- Formulaire d'inscription HTML -->