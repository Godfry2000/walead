<?php
// Vérification des permissions
if ($_SESSION['user_role'] !== 'premium') {
    header('Location: /upgrade.php');
    exit();
}

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

$stmt = $pdo->prepare("SELECT * FROM contacts WHERE user_id = ? LIMIT ? OFFSET ?");
$stmt->execute([$_SESSION['user_id'], $limit, $offset]);
$contacts = $stmt->fetchAll();
?>

<div class="contacts-container">
    <div class="contacts-header">
        <h2>Gestion des Contacts</h2>
        <a href="add.php" class="btn"><i class="fas fa-plus"></i> Nouveau contact</a>
    </div>

    <table class="contacts-table">
        <thead>
            <tr>
                <th>Nom</th>
                <th>Téléphone</th>
                <th>Date d'ajout</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($contacts as $contact): ?>
            <tr>
                <td><?= htmlspecialchars($contact['name']) ?></td>
                <td><?= htmlspecialchars($contact['phone']) ?></td>
                <td><?= date('d/m/Y', strtotime($contact['created_at'])) ?></td>
                <td>
                    <a href="edit.php?id=<?= $contact['id'] ?>" class="action-btn"><i class="fas fa-edit"></i></a>
                    <a href="delete.php?id=<?= $contact['id'] ?>" class="action-btn delete"><i class="fas fa-trash"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>