<div class="security-settings">
    <h2>Sécurité du Compte</h2>
    
    <div class="security-card">
        <h3>Double Authentification</h3>
        <div class="toggle-switch">
            <input type="checkbox" id="2fa-toggle" <?= $user['2fa_enabled'] ? 'checked' : '' ?>>
            <label for="2fa-toggle"></label>
        </div>
    </div>

    <form class="password-form" method="POST">
        <div class="form-group">
            <label>Ancien mot de passe</label>
            <input type="password" name="old_password" required>
        </div>
        
        <div class="form-group">
            <label>Nouveau mot de passe</label>
            <input type="password" name="new_password" required>
        </div>

        <button type="submit" class="btn">Mettre à jour</button>
    </form>
</div>